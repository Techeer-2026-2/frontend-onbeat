import apiClient from "./client";

export const getCommuteProfiles = async (memberId) => {
  const response = await apiClient.get("/commute-profiles", {
    params: { memberId },
  });

  return response.data;
};